package GameOfLife;

import java.util.ArrayList;

public class Board {

    public static final int SIZE = 100;
    public static final int[] penalty1 = {3,8,17,32,47,54,68,72,85,97};
    public static final int[] penalty2 = {5,9,20,33,45,58,64,77,83,95};
    public static final int[] gain = {7,16,21,25,35,40,55,60,75,88,93,99};

    private class squares {
        ArrayList<Player> currentPlayers;
        String activity;

        private squares() {
            currentPlayers = new ArrayList<>();
            activity = "";
        }
    }

    private int numOfPlayers;
    private Player[] totalPlayers;
    squares[] board;

    public Board(int numOfPlayers) {
        this.numOfPlayers = numOfPlayers;
        totalPlayers = new Player[numOfPlayers];
        board = new squares[SIZE];
        populateBoard();
        printBoard();
    }

    void populateBoard() {
        board[1].activity = "Gain";
        for (int i =0; i < penalty1.length;i++) {
            board[penalty1[i]].activity = "Penalty1";
        }

        for (int i =0; i < penalty2.length;i++) {
            board[penalty2[i]].activity = "Penalty2";
        }

        for (int i =0; i < gain.length;i++) {
            board[gain[i]].activity = "Gain";
        }

    }

    void printBoard () {
        for(squares s : board) {
            if(!s.currentPlayers.isEmpty()){
                for(int i = 0; i < s.currentPlayers.size(); i++) {
                    System.out.print(s.currentPlayers.get(i).getName());
                    System.out.print(s.currentPlayers.get(i).getAge());
                    System.out.println(s.currentPlayers.get(i).getMoney());
                }
            }
            System.out.println(s.activity);
        }
    }
}
