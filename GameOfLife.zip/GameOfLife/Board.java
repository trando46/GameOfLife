package GameOfLife;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Board {

    public static final int SIZE = 100;
    public static final int MIN = 0;
    public static final int MAX = 10;
    public static final int[] penalty1 = {3,8,17,32,47,54,68,72,85,97};
    public static final int[] penalty2 = {5,9,20,33,45,58,64,77,83,95};
    public static final int[] gain = {7,16,21,25,35,40,55,60,75,88,93,99};


    private class Squares {
        ArrayList<Player> currentPlayers;
        String activity;

        private Squares() {
            currentPlayers = new ArrayList<>();
            activity = "";
        }
    }

    private int numOfPlayers;
    private HashMap<String,Player> totalPlayers;
    Squares[] board;
    RandomGenerator randomGenerator;

    public Board(int numOfPlayers, Scanner s) {
        this.numOfPlayers = numOfPlayers;
        totalPlayers = new HashMap<>(numOfPlayers);
        createPlayers(s);
        board = new Squares[SIZE];
        randomGenerator = new RandomGenerator(MIN, MAX);
        populateBoard();
        printBoard();
    }

    void createPlayers(Scanner s) {
        String name;
        for(int i =0; i < numOfPlayers; i++){
            int playerNum = i+1;
            System.out.println("Creating player " + playerNum);
            System.out.print("Enter Player name: ");
            name = s.next();
            Player player = new Player(name);
            totalPlayers.put(name,player);
        }
    }

    void populateBoard() {
        for(int i =0; i < SIZE; i++) {
            Squares squares = new Squares();
            board[i] = squares;
        }
        for (int index : penalty1) {
            board[index].activity = "Penalty1";
        }

        for (int index : penalty2) {
            board[index].activity = "Penalty2";
        }

        for (int index : gain) {
            board[index].activity = "Gain";
        }

    }

    void printBoard () {
        for(Squares s : board) {
            if(!s.currentPlayers.isEmpty()){
                for(int i = 0; i < s.currentPlayers.size(); i++) {
                    System.out.print(s.currentPlayers.get(i).getName());
                    System.out.print(s.currentPlayers.get(i).getAge());
                    System.out.println(s.currentPlayers.get(i).getMoney());
                }
            }
            System.out.println(s.activity);
        }
    }

    public void userTurn(String user, Scanner keyboard) {
        System.out.println("\n"+ user +" , it is your chance, roll a number");
        randomGenerator.setNum(MIN, MAX);
        int n = randomGenerator.getNum();


    }
}
