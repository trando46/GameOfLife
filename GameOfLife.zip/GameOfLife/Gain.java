package GameOfLife;

import java.util.Random;
public class Gain {
    public static final int MIN = 50;
    public static final int MAX = 150;
    public static RandomGenerator randomGenerator = new RandomGenerator(MIN,
            MAX);


    private static int generateMoney(Player player)
    {
        randomGenerator.setNum(MIN,MAX);
        int money = randomGenerator.getNum();
        return money;
    }
}
