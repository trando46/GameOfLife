package GameOfLife;

import java.util.Random;
public class Gain {
    public static final int MIN = 50;
    public static final int MAX = 150;


    private static int generateMoney(Player player)
    {
        RandomGenerator randomGenerator = new RandomGenerator(MIN, MAX);
        int money = randomGenerator.getNum();
        return money;
    }
}
