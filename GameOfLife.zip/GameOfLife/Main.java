package GameOfLife;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter total num of players: ");
        int numOfPlayers = s.nextInt();
        HashMap<String, Player> list = new HashMap<>();
        createPlayers(s, numOfPlayers,list);
        Board board = new Board(numOfPlayers,s,list );
        board.takingTurns(s);
    }

    private static void createPlayers(Scanner s, int n, HashMap<String, Player> list) {
        String name;
        for(int i =0; i < n; i++){
            int playerNum = i+1;
            System.out.println("Creating player " + playerNum);
            System.out.print("Enter Player name: ");
            name = s.next();
            Player player = new Player(name);
            list.put(name,player);
        }
    }
}
