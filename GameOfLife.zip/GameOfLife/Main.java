package GameOfLife;

public class Main {

    public static void main(String[] args) {
        Board board = new Board(4);
    }
}
