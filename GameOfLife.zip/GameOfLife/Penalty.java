package GameOfLife;

import java.util.ArrayList;
import java.util.HashMap;

public class Penalty
{
    TwentyOne twentyOne;
    private int condition;
    Penalty(int condition) {
        this.condition = condition;
        twentyOne = new TwentyOne();
    }

    public String playPenalty(HashMap<String, Player> list, Player player,
                             int condition)
    {
        twentyOne.play21(condition,list, player);
        String win = twentyOne.getWinner();
        return win;
    }

}
