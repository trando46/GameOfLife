package GameOfLife;

import java.util.ArrayList;

public class Penalty
{
    Penalty(int condition)
    {
    }

    public static String condition1(int condition, String name,
                                   ArrayList<Player> list)
    {
        TwentyOne twentyOne = new TwentyOne(condition, name, list);
        String win = twentyOne.getWinner();
        return win;
    }
    public static String condition2(TwentyOne twentyOne,
                                String option)
    {
        String win = "";
        if (option == "1" || option == "2" || option ==
                "3" || option == "4" || option == "5" || option == "6")
        win  = twentyOne.getWinner();
        return win;
    }
}
