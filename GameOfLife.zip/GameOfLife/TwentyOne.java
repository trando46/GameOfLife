package GameOfLife;

import java.util.*;


public class TwentyOne {

    int min = 1;
    int max = 10;
    private int currentHand;
    private int currentLenghtMap;
    private int noDeal;
    //private String name;
    private String winner;
    RandomGenerator randomGenerator;

    //TODO: MIGHT NOT NEED THIS
    private HashMap<String, Integer> players;


    //TODO: need to change the argument to pass in the Player's object
    public TwentyOne () {
        currentHand = 0;
        currentLenghtMap = 0;
        noDeal = 0;
        //this.name = name;
        players = new HashMap<>();
        randomGenerator = new RandomGenerator(min, max);
    }


    private void playAll(HashMap<String, Player> users){

        for (Map.Entry<String, Player> entry : users.entrySet()){
            playSingle(entry.getValue());
        }

        //TODO: comparison
        int maxValueInMap=(Collections.max(players.values()));
        for (Map.Entry<String, Integer> entry : players.entrySet()) {
            if (entry.getValue() == maxValueInMap) {
                winner = entry.getKey();
            }
        }
    }

    public String getWinner(){
        return winner;
    }

    public void welcome(){

        System.out.println("-----------Welcome to the game 21! -----------");
        System.out.println("-- Rules:                                   --");
        System.out.println("-- 1) If your hand is over 21 - GAME OVER!  --");
        System.out.println("-- 2) Closest number to 21 - Win!           --");
        System.out.println("----------------------------------------------");
    }

    public void menu(){
        System.out.println("-- Menu --");
        System.out.println("Please select 1 or 2");
        System.out.println("1) Deal card.");
        System.out.println("2) Stay (NO CARD FOR THE REST OF 21)");
    }

    //TODO: replace the string name and pass in the player's object instead.
    public void addPlayer(Player player){

        players.put(player.getName(),currentHand);
    }

    public void userPick(int pick, Player player){

        int max = 10, min = 1;

        // User want to get another card
        if(pick == 1){
            // generate another random number for that user
            //TODO: add the randomgenrator class that MIA created
            randomGenerator.setNum(min, max);
            int card = randomGenerator.getNum();
            currentHand += card;
            String name = player.getName();
            if(players.containsKey(name) ){
                players.put(name, players.get(name) + card);
            }
            else{
                players.put(player.getName(),currentHand);
            }

        }

        if(pick == 2){
            // add 0 to that user hand.
            currentHand += 0;
            noDeal++;
            String name = player.getName();
            if(players.containsKey(name) ){
                players.put(name, players.get(name));
            }
            else{
                players.put(player.getName(),currentHand);
            }
        }

    }

    public boolean isIt21(){
        if(currentHand > 21){
            return true;
        }
        return false;
    }

    public StringBuilder displayPlayer(Player player){
        StringBuilder str = new StringBuilder();

        for(String item: players.keySet()){
            str.append("Player: " + item + " Hands: " + players.get(item) + "\n");
        }
        return str;
    }




    //TODO: need to change the parameter to pass in the player's object
    private void playSingle(Player player){

        //TODO: need to pass in the player's object
        addPlayer(player);

        // Create a scanner object
        Scanner in = new Scanner(System.in);
        int selection;

        do{
            System.out.println(displayPlayer(player));
            menu();
            System.out.print("Select: ");
            selection = in.nextInt();

            while (selection != 1 && selection != 2)
            {
                System.out.println("ERROR: Please enter 1 or 2");
                System.out.print("Select: ");
                selection = in.nextInt();
            }

            userPick(selection, player);

            if(isIt21() == true){
               System.out.println("Game over");
               winner = "Dealer";
            }

        } while (noDeal != players.size() && isIt21() != true);

        currentHand = 0;

    }

    public void play21(int condition, HashMap<String, Player> list,
                    Player player) {
        if(condition == 1 ) {
            playAll(list);
        }
        else {
            playSingle(player);
        }
    }


}
