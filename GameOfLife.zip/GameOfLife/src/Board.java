/*
 * @author Supraja Amrutha
 */


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Board {

    public static final int SIZE = 100;
    public static final int MIN = 1;
    public static final int MAX = 10;
    public static final int[] penalty1 = {3,8,17,32,47,54,68,72,85,97};
    public static final int[] penalty2 = {5,9,20,33,45,58,64,77,83,95};
    public static final int[] gain = {7,16,21,25,35,40,55,60,75,88,93,99};


    private class Squares {
        ArrayList<Player> currentPlayers;
        String activity;

        private Squares() {
            currentPlayers = new ArrayList<>();
            activity = "";
        }
    }

    private int numOfPlayers;
    private HashMap<String,Player> totalPlayers;
    private Squares[] board;
    private RandomGenerator randomGenerator;

    public Board(int numOfPlayers, Scanner s, HashMap< String, Player> list) {
        this.numOfPlayers = numOfPlayers;
        totalPlayers = list;
        board = new Squares[SIZE];
        randomGenerator = new RandomGenerator(MIN, MAX);
        populateBoard();
        printBoard();
    }


    void populateBoard() {
        for(int i =0; i < SIZE; i++) {
            Squares squares = new Squares();
            board[i] = squares;
            board[i].activity = "        ";
        }
        for (int index : penalty1) {
            board[index].activity = "Penalty1";
        }

        for (int index : penalty2) {
            board[index].activity = "Penalty2";
        }

        for (int index : gain) {
            board[index].activity = "Gain    ";
        }

    }

    void printBoard () {
        System.out.println("----------------------------------------------");
        for(Squares s : board) {
            System.out.print("|");
            System.out.print(s.activity + "|");


            if(!s.currentPlayers.isEmpty()){
                for(int i = 0; i < s.currentPlayers.size(); i++) {
                    System.out.print("|");
                    System.out.print(s.currentPlayers.get(i).getName());
                    System.out.print(", ");
                    System.out.print(s.currentPlayers.get(i).getIndex() );
                    System.out.print(", ");
                    System.out.print( "$" + s.currentPlayers.get(i).getMoney());
                    System.out.print("| ");
                }
            }
            System.out.println(
                    "\n----------------------------------------------");

        }
    }

    public void playerTurn(Player player, Scanner s) {

        System.out.println("\n"+ player.getName() +", it is your chance, " +
                "roll a " +
                "number");
        randomGenerator.setNum(MIN, MAX);
        int n = randomGenerator.getNum();
        int index = player.getIndex();
        board[index].currentPlayers.remove(player);
        index = index + n;
        if(index<SIZE) {
            player.setIndex(index);
            System.out.println("\n" + player.getName() + ", you have rolled " +
                    "a " + n +
                    ". Jumping to square number " + index + "!");

            board[index].currentPlayers.add(player);
            if (board[index].activity.equals("Gain    ")) {
                gainExecution(player);
            }
            if (board[index].activity.equals("Penalty1")) {
                penalty1Execution(player);
            }
            if (board[index].activity.equals("Penalty2")) {
                penalty2Execution(player, s, index);
            }
        }
        printBoard();
    }

    private void penalty1Execution(Player player) {
        Penalty penalty = new Penalty(1);
        String winner = penalty.playPenalty(totalPlayers,player,1);
        for(Map.Entry<String, Player> entry : totalPlayers.entrySet()){
            if(winner.equals("Dealer")) {
                System.out.println("No one wins the 21!");
            }
            else {
                if(!entry.getKey().equals(winner)) {
                    entry.getValue().subtractMoney(100);
                }
                else{
                    System.out.println(winner + " you won 21! Adding $100 to your" +
                            " account");
                    entry.getValue().addMoney(100);
                }
            }
        }
    }

    private void gainExecution(Player player) {
        int money = Gain.generateMoney();
        player.addMoney(money);
    }

    private void penalty2Execution(Player player, Scanner s, int index) {
        String option;
        System.out.println("1. Sky dive");
        System.out.println("2. Scuba Diving");
        System.out.println("3. Bungee Jumping");
        System.out.println("4. Skiing");
        System.out.println("5. Swimming");
        System.out.println("6. Amusement park rides");
        System.out.print("Choose one from the above options: ");
        option = s.next();
        try{
            int choice = Integer.parseInt(option);
            if (choice == 1 || choice == 2 || choice ==
                    3 || choice == 4 || choice == 5 || choice == 6) {
                Penalty penalty = new Penalty(choice);
                String winner = penalty.playPenalty(totalPlayers, player, 2);
                if (winner.equals("Dealer")) {
                    System.out.println("Game Over for " + player.getName() +
                            " !");
                    player.setStatus("Dead");
                    board[index].currentPlayers.remove(player);
                    totalPlayers.remove(player.getName());
                }
                else {
                    System.out.println(player.getName() +" played safe! " +
                            "Continuing the game!");
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Input a valid number!");
        }
    }

    public void takingTurns(Scanner s) {
        Player[] players = totalPlayers.values().toArray(new Player[numOfPlayers]);
        int count =0;
        while(board[SIZE-1].currentPlayers.isEmpty() && totalPlayers.size() > 1) {
            for(int i =0; i < players.length; i++) {
                if(totalPlayers.containsKey(players[i].getName())) {
                    playerTurn(players[i], s);
                    count++;
                    if(count >= players.length){
                        break;
                    }
                    if(totalPlayers.size() ==1) {
                        for(i =0; i < players.length; i++){
                            String key = players[i].getName();
                            if(totalPlayers.containsKey(key)){
                                System.out.println("\n" + totalPlayers.get(key).getName()
                                        + " you won the " + "game!");
                                break;
                            }
                        }
                    }
                }
            }
            count =0;
        }
    }


}
