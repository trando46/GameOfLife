/**
 * @author: Bhagyashree Aras
 */

import java.util.HashMap;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class BoardTest {

    @org.junit.jupiter.api.Test
    void populateBoard()
    {
        Scanner scanner = new Scanner(System.in);
        HashMap<String, Player> list = new HashMap<>();
        Board board = new Board(2, scanner,list);
        Board board1 = new Board(4, scanner,list);

        assertNotSame(board,board1);
    }

    @org.junit.jupiter.api.Test
    void printBoard()
    {
        Scanner scanner = new Scanner(System.in);
        HashMap<String, Player> list = new HashMap<>();
        Board board = new Board(2, scanner,list);
        board.printBoard();
    }

    @org.junit.jupiter.api.Test
    void playerTurn()
    {
        Player player = new Player("Shree");
        Scanner scanner = new Scanner(System.in);
        HashMap<String, Player> list = new HashMap<>();
        Board board = new Board(2, scanner,list);
        board.playerTurn(player,scanner);
    }
}