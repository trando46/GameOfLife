import java.util.Random;
public class Gain {
    Gain(){
    }

    private static void generateMoney(Player player)
    {
        Random random = new Random();
        int min = 50;
        int max = 150;
        int random_int = (int)(Math.random() * (max - min + 1) + min);
        player.setMoney(random_int);
    }
}
