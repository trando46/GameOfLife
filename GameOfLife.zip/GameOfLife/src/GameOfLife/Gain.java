/*
 * @author Bhagyashree Aras
 */


package GameOfLife;

import java.util.Random;
public class Gain {
    public static final int MIN = 50;
    public static final int MAX = 150;
    public static RandomGenerator randomGenerator = new RandomGenerator(MIN,
            MAX);


    public static int generateMoney()
    {
        randomGenerator.setNum(MIN,MAX);
        int money = randomGenerator.getNum();
        return money;
    }
}
