/*
 * @author Supraja Amrutha, Mia Lee, Bhagyashree Aras, Bao Tran Do
 */


package GameOfLife;

import java.util.HashMap;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int numOfPlayers;
        do {
            System.out.print("\nEnter total num of players (Min 2 and Max 6):" +
                    " ");
            numOfPlayers = s.nextInt();
        }while (numOfPlayers <= 1 || numOfPlayers >= 6);
        HashMap<String, Player> list = new HashMap<>();
        createPlayers(s, numOfPlayers,list);
        Board board = new Board(numOfPlayers,s,list );
        board.takingTurns(s);
        System.out.println("\nThanks for playing Game of Life!");
    }

    private static void createPlayers(Scanner s, int n, HashMap<String, Player> list) {
        String name;
        for(int i =0; i < n; i++){
            int playerNum = i+1;
            System.out.println("\nCreating player " + playerNum);
            System.out.print("Enter Player name: ");
            name = s.next();
            Player player = new Player(name);
            list.put(name,player);
        }
    }
}
