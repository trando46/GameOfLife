/**
 * @author : Bhagyashree Aras
 */

import org.junit.jupiter.api.Test;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.*;

class PenaltyTest {

    @Test
    void playPenalty()
    {
        Player player = new Player("Shree");
        HashMap<String, Player> list = new HashMap<>();
        list.put("Shree", player);
        Penalty penalty = new Penalty(1);
        String win = penalty.playPenalty(list, player, 1);
        if (win != null)
            assert true;
    }
}