/**
 * @ author: Bhagyashree Aras
 */

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlayerTest {

    @Test
    void setName()
    {
        Player player = new Player("Tran");
        player.setName("Shree");
        assertNotSame(player.getName(), "Tran");
    }

    @Test
    void setMoney()
    {
        Player player = new Player("Shree");
        player.setMoney(100);
        assertEquals(100,player.getMoney());
    }

    @Test
    void addMoney()
    {
        Player player = new Player("Shree");
        player.setMoney(100);
        player.addMoney(50);
        assertEquals(150,player.getMoney());
    }

    @Test
    void subtractMoney()
    {
        Player player = new Player("Shree");
        player.setMoney(100);
        player.subtractMoney(50);
        assertEquals(50,player.getMoney());
    }

    @Test
    void addAge()
    {
        Player player = new Player("Shree");
        player.addAge(2);
        assertEquals(2,2);
    }

    @Test
    void subtractAge() {
        Player player = new Player("Shree");
        player.addAge(1);
        assertEquals(1,1);
    }


    @Test
    void setHand21()
    {
        Player player = new Player("Shree");
        player.setHand21(21);
        assertEquals(player.getHand21(),21);
    }

    @Test
    void addHand21() {
        Player player = new Player("Shree");
        player.setHand21(10);
        player.addHand21(3);
        assertEquals(player.getHand21(),13);
    }

    @Test
    void setStatus()
    {
        Player player = new Player("Shree");
        player.setStatus("alive");
        assertNotSame(player.getStatus(),"dead");
    }

    @Test
    void setIndex()
    {
        Player player = new Player("Shree");
        player.setIndex(2);
        assertEquals(player.getIndex(),2);
    }

    @Test
    void getName() {
        Player player = new Player("Shree");
        player.setName("Shree");
        assertSame(player.getName(), "Shree");
    }

    @Test
    void getMoney()
    {
        Player player = new Player("Shree");
        player.setMoney(100);
        player.setMoney(120);
        assertEquals(player.getMoney(),120);
    }

    @Test
    void getAge()
    {
        Player player = new Player("Shree");
        player.addAge(2);
        player.addAge(4);
        assertEquals(player.getAge(),6);
    }

    @Test
    void getHand21()
    {
        Player player = new Player("Shree");
        player.setHand21(21);
        player.setHand21(13);
        assertEquals(player.getHand21(),13);
    }

    @Test
    void getStatus()
    {
        Player player = new Player("Shree");
        player.setStatus("Dead");
        player.setStatus("Alive");
        assertSame(player.getStatus(),"Alive");
    }

    @Test
    void getIndex()
    {
        Player player = new Player("Shree");
        player.setIndex(2);
        player.setIndex(3);
        assertNotNull(player.getIndex());
    }
}