/**
 * @author: Bhagyashree Aras
 */

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RandomGeneratorTest {

    @Test
    void setNum()
    {
        RandomGenerator randomGenerator = new RandomGenerator(0,10);
        randomGenerator.setNum(10, 20);
        int num = randomGenerator.getNum();
        if (num > 10 && num < 20){
            assert true;
        }

    }

    @Test
    void getNum()
    {
        RandomGenerator randomGenerator = new RandomGenerator(0,10);
        int num = randomGenerator.getNum();
        if (num > 0 && num < 10){
            assert true;
        }
    }
}