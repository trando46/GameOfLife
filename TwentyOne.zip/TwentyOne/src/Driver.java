import java.util.HashMap;

public class Driver {

    public static void main(String[] args){
        TwentyOne game = new TwentyOne();
        game.welcome();
        String name = "Tran";  //TODO: instead of String it should be player's object
        game.game(name);

    }


}
